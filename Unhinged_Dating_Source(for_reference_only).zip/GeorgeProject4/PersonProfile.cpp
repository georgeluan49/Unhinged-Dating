//
//  PersonProfile.cpp
//  PersonProfile
//
//  Created by Qitong Luan on 3/5/22.
//

#include "PersonProfile.h"
#include <iostream>
#include <set>
int PersonProfile::GetNumAttValPairs() const {
    return n_attvalpair;
}

PersonProfile::PersonProfile(std::string name, std::string email)
:m_name(name), m_email(email)
{}

PersonProfile::~PersonProfile(){}

std::string PersonProfile::GetName() const {
    return m_name;
}

std::string PersonProfile::GetEmail() const {
    return m_email;
}

void PersonProfile::AddAttValPair(const AttValPair& attval) {
    std::set<std::string>* target= m_attval.search(attval.attribute);
    if (target == nullptr) {
        std::set<std::string> insertSet;
        insertSet.insert(attval.value);
        m_attval.insert(attval.attribute, insertSet);
        enumerateAttVal.push_back(attval);
        n_attvalpair++;
    }
    else {
        if ((target->insert(attval.value)).second) {
            enumerateAttVal.push_back(attval);
            n_attvalpair++;
        }
    }
}

bool PersonProfile::GetAttVal(int attribute_num, AttValPair& attval) const {
    if (attribute_num < 0 || attribute_num >= n_attvalpair) return false;
    attval = enumerateAttVal[attribute_num];
    return true;
}
