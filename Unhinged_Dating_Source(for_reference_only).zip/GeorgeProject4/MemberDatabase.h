//
//  MemberDatabase.h
//  PersonProfile
//
//  Created by Qitong Luan on 3/5/22.
//

#ifndef MemberDatabase_h
#define MemberDatabase_h

#include <string>
#include <vector>
#include "provided.h"
#include "RadixTree.h"
#include "PersonProfile.h"

class MemberDatabase {
public:
    MemberDatabase();
    bool LoadDatabase(std::string filename);
    bool AddAMember();
    std::vector<std::string> FindMatchingMembers(const AttValPair& input) const;
    const PersonProfile* GetMemberByEmail(std::string email) const;
    bool exportToFile(std::string filepath) const;
    ~MemberDatabase();
private:
    RadixTree<PersonProfile*> emailToProfile;
    std::vector<PersonProfile*> profilePtrs; // This facilitates the deletion of dynamically allocated profiles.
    RadixTree<std::vector<std::string> > attValToEmail;
};

#endif /* MemberDatabase_h */
