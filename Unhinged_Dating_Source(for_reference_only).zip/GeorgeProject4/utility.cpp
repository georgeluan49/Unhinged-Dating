//
//  utility.cpp
//  GeorgeProject4
//
//  Created by Qitong Luan on 3/7/22.
//

#include "utility.h"

bool operator== (const AttValPair& lhs, const AttValPair& rhs){
    return (lhs.attribute == rhs.attribute && lhs.value == rhs.value);
}

bool operator < (const AttValPair& lhs, const AttValPair& rhs){
    return (lhs.value < rhs.value);
}

bool rank(const EmailCount& lhs, const EmailCount& rhs)
{
      /* The person with the higher total matches should come first.  If they have
      the same total matches, then they will be ranked alphabetically according to their email.*/

    if (lhs.count > rhs.count)
        return true;
    if (lhs.count < rhs.count)
        return false;
    return lhs.email < rhs.email;
}

#ifdef _WIN32

#pragma warning(disable : 4005)
#include <windows.h>

void clearScreen()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hConsole, &csbi);
    DWORD dwConSize = csbi.dwSize.X * csbi.dwSize.Y;
    COORD upperLeft = { 0, 0 };
    DWORD dwCharsWritten;
    FillConsoleOutputCharacter(hConsole, TCHAR(' '), dwConSize, upperLeft,
                                                        &dwCharsWritten);
    SetConsoleCursorPosition(hConsole, upperLeft);
}

#else  // not _WIN32

#include <iostream>
#include <cstring>
#include <cstdlib>

void clearScreen()  // will just write a newline in an Xcode output window
{
    static const char* term = getenv("TERM");
    if (term == nullptr  ||  strcmp(term, "dumb") == 0)
        std::cout << std::endl;
    else
    {
        static const char* ESC_SEQ = "\x1B[";  // ANSI Terminal esc seq:  ESC [
        std::cout << ESC_SEQ << "2J" << ESC_SEQ << "H" << std::flush;
    }
}

#endif
