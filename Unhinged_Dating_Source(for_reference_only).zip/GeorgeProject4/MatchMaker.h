//
//  MatchMaker.h
//  GeorgeProject4
//
//  Created by Qitong Luan on 3/3/22.
//

#ifndef MatchMaker_h
#define MatchMaker_h
#include "provided.h"
#include <vector>

class MemberDatabase;
class AttributeTranslator;

class MatchMaker {
public:
    MatchMaker(const MemberDatabase& mdb, const AttributeTranslator& at);
    ~MatchMaker();
    std::vector<EmailCount> IdentifyRankedMatches(std::string email,
                                                  int threshold) const;

private:
    const MemberDatabase* m_MemberDatabase;
    const AttributeTranslator* m_AttributeTranslator;
};

#endif /* MatchMaker_h */
