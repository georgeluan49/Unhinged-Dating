//
//  RadixTree.h
//  AttributeTranslator
//
//  Created by Qitong Luan on 3/5/22.
//

#ifndef RadixTree_h
#define RadixTree_h
#include <string>
const int MAX_CHAR_ARRAY_LENGTH = 128;
template <typename ValueType>
class RadixTree {
public:
    RadixTree();
    ~RadixTree();
    void insert(std::string key, const ValueType& value);
    ValueType* search(std::string key) const;

private:
    struct Node {
        std::string charSequence;
        Node* nextNodes[MAX_CHAR_ARRAY_LENGTH];
        ValueType* value = nullptr;
        Node(const std::string sequence)
        {
            charSequence = sequence;
            for (int i = 0; i < MAX_CHAR_ARRAY_LENGTH; i++) // starts with all nullptrs
                nextNodes[i] = nullptr;
        }
    };
    
    Node* root = nullptr;
    
    void cleanup(Node* killMe) {
        if (killMe == nullptr) return;
        for (int i = 0; i < MAX_CHAR_ARRAY_LENGTH; i++)
            cleanup(killMe->nextNodes[i]);
        delete killMe->value;
        delete killMe;
    }
};

template <typename ValueType>
RadixTree<ValueType>::RadixTree()
{
    root = new Node(""); // This is a dummy node that helps with insertion
}

template <typename ValueType>
RadixTree<ValueType>::~RadixTree() {
    cleanup(root);
}

template <typename ValueType>
void RadixTree<ValueType>::insert(std::string key, const ValueType& value) {
    // The array nextNodes is index by the first char of the string
    // Extracting it to an int is merely used to silence warnings
    int keyIndex = key.at(0);
    // if the tree does not contain any common prefix with the key, just go insert the key in the corresponding slot
    if (root->nextNodes[keyIndex] == nullptr) {
        root->nextNodes[keyIndex] = new Node(key);
        root->nextNodes[keyIndex]->value = new ValueType(value);
        return;
    }
    // Pointers used to traverse through the tree
    Node* curr = root->nextNodes[keyIndex];
    Node* pre = root;
    while (curr != nullptr) {
        //if the key is found, go insert there
        if (curr->charSequence == key) {
            //prevent memory leak
            if (curr->value != nullptr)
                delete curr->value;
            curr->value = new ValueType(value);
            break;
        }
        int i = 0;
        bool runout = true;
        for (i = 0; (i < curr->charSequence.size() && i < key.size()); i++ ) {
            // find the first letter at which the two strings differ from each other
            if (key.at(i) != curr->charSequence.at(i)) {
                runout = false;
                break;
            }
        }
        if (!runout) { // what to do if we need to split out a common prefix
            std::string commonPrefix = key.substr(0, i);
            pre->nextNodes[keyIndex] = new Node(commonPrefix);
            pre = pre->nextNodes[keyIndex];
            curr->charSequence = curr->charSequence.substr(i, curr->charSequence.size() - i);
            int valIndex = curr->charSequence.at(0);
            pre->nextNodes[valIndex] = curr;
            key = key.substr(i, key.size() - i);
            keyIndex = key.at(0);
            pre->nextNodes[keyIndex] = new Node(key);
            pre->nextNodes[keyIndex]->value = new ValueType(value);
            break;
        }
        else { // what to do if we just want to add a suffix
            if (i >= key.size()) {
                pre->nextNodes[keyIndex] = new Node(key);
                pre->nextNodes[keyIndex]->value = new ValueType(value);
                pre = pre->nextNodes[keyIndex];
                curr->charSequence = curr->charSequence.substr(i, curr->charSequence.size() - i);
                int valIndex = curr->charSequence.at(0);
                pre->nextNodes[valIndex] = curr;
                break;
            }
            else {
                key = key.substr(i, key.size() - i);
                keyIndex = key.at(0);
                pre = curr;
                curr = curr->nextNodes[keyIndex];
            }
        }
    }
    // takes care of the end of the string
    if (curr == nullptr) {
        pre->nextNodes[keyIndex] = new Node(key);
        pre->nextNodes[keyIndex]->value = new ValueType(value);
    }
}

template <typename ValueType>
inline
ValueType* RadixTree<ValueType>::search(std::string key) const {
    int keyIndex = key.at(0);
    //can't possibly be in the tree if we can't even locate its first letter in the tree
    if (root->nextNodes[keyIndex] == nullptr) return nullptr;
    ValueType* returnVal = nullptr;
    Node* p = root->nextNodes[keyIndex];
    while (p != nullptr) {
        if (p->charSequence.size()>key.size()||key.substr(0, p->charSequence.size())!= p->charSequence)
            return nullptr;
        key = key.substr(p->charSequence.size(), key.size() - p->charSequence.size());
        if (key == "") {
            if (p->value == nullptr) return nullptr; // in this case the key is not an actual word in the tree, it's just a prefix
            else {
                returnVal = p->value;
                break;
            }
        }
        keyIndex = key.at(0);
        p = p->nextNodes[keyIndex];
    }
    return returnVal;
}
#endif /* RadixTree_h */
