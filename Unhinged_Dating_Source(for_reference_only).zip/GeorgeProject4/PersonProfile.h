//
//  PersonProfile.h
//  PersonProfile
//
//  Created by Qitong Luan on 3/5/22.
//

#ifndef PersonProfile_h
#define PersonProfile_h
#include "RadixTree.h"
#include "provided.h"
#include <vector>
#include <set>
#include <string>

class PersonProfile {
public:
    PersonProfile(std::string name, std::string email);
    ~PersonProfile();
    std::string GetName() const;
    std::string GetEmail() const;
    void AddAttValPair(const AttValPair& attval);
    int GetNumAttValPairs() const;
    bool GetAttVal(int attribute_num, AttValPair& attval) const;

private:
    RadixTree<std::set<std::string> > m_attval;
    int n_attvalpair = 0;
    std::vector<AttValPair> enumerateAttVal; // This ensures the O(1) for GetAttVal().
    std::string m_name;
    std::string m_email;
};

#endif /* PersonProfile_h */
