//
//  MemberDatabase.cpp
//  PersonProfile
//
//  Created by Qitong Luan on 3/5/22.
//

#include "MemberDatabase.h"
#include "PersonProfile.h"
#include "utility.h"
#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
MemberDatabase::MemberDatabase(){}

bool MemberDatabase::LoadDatabase(std::string filename) {
    std::ifstream dataFile(filename);
    if (!dataFile)
        return false;
    std::string line;
    std::stringstream member;
    while (std::getline(dataFile, line)||member.str()!="") { /* Continue to process the input either if there are still lines left in the ifstream or there are input in the stringstream object left to process. */
        // The part after "||" ensures the the last member is processed.
        if (line != "") {
            member << (line + "\n"); // record the member's info
        }
        else {
            std::getline(member, line);
            std::string name = line;
            std::getline(member, line);
            std::string email = line;
            if (emailToProfile.search(email) != nullptr) return false; // if there are duplicates, return false
            PersonProfile* person = new PersonProfile(name, email);
            std::getline(member, line); // skip the number part
            while (std::getline(member, line)) { // process the attributes
                int i = 0;
                while (line.at(i) != ',') i++;
                AttValPair insert;
                insert.attribute = line.substr(0, i);
                insert.value = line.substr(i+1,line.size()-i-1);
                person->AddAttValPair(insert);
                std::vector<std::string>* result = attValToEmail.search(line);
                if (result == nullptr) {
                    std::vector<std::string> insertVec;
                    insertVec.push_back(email);
                    attValToEmail.insert(line, insertVec);
                }
                else {
                    if(std::find(result->begin(), result->end(), email) == result->end())
                        result->push_back(email);
                }
            }
            emailToProfile.insert(email, person);
            profilePtrs.push_back(person);
            // reset the stringstream object
            member.str("");
            member.clear();
        }
    }
    return true;
}
bool MemberDatabase::AddAMember() {
    std::string email, name;
    AttValPair inputAttVal;
    std::cout << "What is the name?" << std::endl;
    std::getline(std::cin, name);
    if (name == "") {
        std::cout << "The name cannot be empty." << std::endl;
        return false;
    }
    
    std::cout << "What is the email address?" << std::endl;
    std::getline(std::cin, email);
    if (email == "") {
        std::cout << "The email address cannot be empty." << std::endl;
        return false;
    }
    
    PersonProfile* insertProfile = new PersonProfile(name, email);
    
    for (;;) {
        std::cout << "What is the attribute? (Press ENTER to complete) " << std::endl;
        std::getline(std::cin, inputAttVal.attribute);
        if (inputAttVal.attribute == "")
            break;
        std::cout << "What is the value? " << std::endl;
        std::getline(std::cin, inputAttVal.value);
        if (inputAttVal.value == "")
            break;
        
        insertProfile->AddAttValPair(inputAttVal);
        std::vector<std::string>* result = attValToEmail.search(inputAttVal.attribute + "," + inputAttVal.value);
        if (result == nullptr) {
            std::vector<std::string> insertVec;
            insertVec.push_back(email);
            attValToEmail.insert(inputAttVal.attribute + "," + inputAttVal.value, insertVec);
        }
        else {
            if(std::find(result->begin(), result->end(), email) == result->end())
                result->push_back(email);
        }
    }
    emailToProfile.insert(email, insertProfile);
    profilePtrs.push_back(insertProfile);
    
    std::cout << "Profile saved!" << std::endl;
    clearScreen();
    
    return true;
}
std::vector<std::string> MemberDatabase::FindMatchingMembers(const AttValPair& input) const
{
    std::vector<std::string> returnVal;
    std::vector<std::string>* result = attValToEmail.search(input.attribute + "," + input.value);
    if (result == nullptr)
        return returnVal;
    return *result;
}

const PersonProfile* MemberDatabase::GetMemberByEmail(std::string email) const {
    PersonProfile** result = emailToProfile.search(email);
    if (result == nullptr)
        return nullptr;
    else
        return *result;
}

bool MemberDatabase::exportToFile(std::string filepath) const {
    std::ofstream file(filepath, std::ofstream::out);
    if (!file.is_open()) {
        std::cout << "Export failed! Please try again with a valid file path." << std::endl;
        return false;
    }
    else {
        std::cout << "Exporting in progress... Please wait!" << std::endl;
        std::vector<PersonProfile*>::const_iterator it = profilePtrs.begin();
        std::stringstream member;
        while (it != profilePtrs.end()) {
            
            // Enter the name and the email
            
            member << (*it)->GetName() << '\n';
            member << (*it)->GetEmail() << '\n';
            
            // Figure out the number of attributes
            
            int numAttribute = (*it)->GetNumAttValPairs();
            std::string numAttString = "";
            numAttString += (numAttribute + '0');
            member << numAttString << '\n';
            // Get the AttVal pairs
            
            for (int i = 0; i < numAttribute; i++) {
                AttValPair av;
                (*it)->GetAttVal(i, av);
                member << av.attribute << "," << av.value << '\n';
            }
            if (it != profilePtrs.end()-1)
                file << member.str() << '\n';
            else
                file << member.str();
            
            // reset the stringstream object
            member.str("");
            member.clear();
            
            it++;
        }
        file.close();
        std::cout << "Export completed!" << std::endl;
        clearScreen();
        return true;
    }
}

MemberDatabase::~MemberDatabase(){
    std::vector<PersonProfile*>::iterator killMe = profilePtrs.begin();
    while (killMe != profilePtrs.end()) {
        delete *killMe;
        killMe++;
    }
}
