//main.cpp

#include "PersonProfile.h"
#include "AttributeTranslator.h"
#include "MemberDatabase.h"
#include "MatchMaker.h"
#include "provided.h"
#include "utility.h"
#include <iostream>
#include <string>
#include <vector>

std::string MEMBERS_FILE = "/Users/qitongluan/Documents/CS/CS 32/GeorgeProject4/GeorgeProject4/members.txt";
std::string TRANSLATOR_FILE = "/Users/qitongluan/Documents/CS/CS 32/GeorgeProject4/GeorgeProject4/translator.txt";

bool findMatches(const MemberDatabase& mdb, const AttributeTranslator& at);

void menu(int& selection);

int main() {
    MemberDatabase mdb;
    std::cout << "Please enter the path of your member database: ";
    std::getline(std::cin, MEMBERS_FILE);
    if (!mdb.LoadDatabase(MEMBERS_FILE))
    {
        std::cout << "Error loading " << MEMBERS_FILE << std::endl;
        return 1;
    }
    AttributeTranslator at;
    std::cout << "Please enter the path of your translator file: ";
    std::getline(std::cin, TRANSLATOR_FILE);
    if (!at.Load(TRANSLATOR_FILE))
    {
        std::cout << "Error loading " << TRANSLATOR_FILE << std::endl;
        return 1;
    }
    std::cout << std::endl;
    
    int selection;
    
    // The following do-while loop keeps the app running
    
    do
    {
        menu(selection);
        if (selection == 1)
        {
            mdb.AddAMember();
        }
        else if (selection == 2)
        {
            findMatches(mdb, at);
        }
        else if (selection == 3)
        {
            std::string exportPath;
            std::cout << "Please enter the path (w/ destination file name)." << std::endl;
            getline(std::cin, exportPath);
            mdb.exportToFile(exportPath);
        }
        else if (selection != 0)
        {
            std::cout << "Invalid option!" << std::endl;
        }
        clearScreen();
    } while (selection != 0);
    std::cout << "Happy dating!" << std::endl;
}

bool findMatches(const MemberDatabase& mdb, const AttributeTranslator& at)
{
      // Prompt for email
    std::string email;
    const PersonProfile* pp;
    for (;;) {
        std::cout << "Enter the member's email for whom you want to find matches: ";
        std::getline(std::cin, email);
        if (email.empty())
            return false;
        pp = mdb.GetMemberByEmail(email);
        if (pp != nullptr)
            break;
        std::cout << "That email is not in the member database." << std::endl;
    }

      // Show member's attribute-value pairs
    std::cout << "The member has the following attributes:" << std::endl;
    for (int k = 0; k != pp->GetNumAttValPairs(); k++) {
        AttValPair av;
        pp->GetAttVal(k, av);
        std::cout << av.attribute << " --> " << av.value << std::endl;
    }

      // Prompt user for threshold
    int threshold;
    std::cout << "How many shared attributes must matches have? ";
    std::cin >> threshold;
    std::cin.ignore(10000, '\n'); 

      // Print matches and the number of matching translated attributes
    MatchMaker mm(mdb, at);
    std::vector<EmailCount> emails = mm.IdentifyRankedMatches(email, threshold);
    if (emails.empty())
        std::cout << "No member was a good enough match." << std::endl;
    else {
        std::cout << "The following members were good matches:" << std::endl;;
        for (const auto& emailCount : emails) {
            const PersonProfile* pp = mdb.GetMemberByEmail(emailCount.email);
            std::cout << pp->GetName() << " at " << emailCount.email << " with "
                      << emailCount.count << " matches!" << std::endl;
        }
    }
    std::cout << std::endl;
    return true;
}

void menu(int& selection)
{
    std::cout << "What do you want to do today?" << std::endl;
    std::cout << "Press 1 to add a new profile" << std::endl;
    std::cout << "Press 2 to find matches" << std::endl;
    std::cout << "Press 3 to export current database" << std::endl;
    std::cout << "Press 0 to quit" << std::endl;
    std::cin >> selection;
    std::cin.ignore(10000, '\n');
}
