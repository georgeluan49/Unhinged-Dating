//
//  utility.h
//  GeorgeProject4
//
//  Created by Qitong Luan on 3/3/22.
//

#ifndef utility_h
#define utility_h
#include "provided.h"
bool operator== (const AttValPair& lhs, const AttValPair& rhs);

bool operator < (const AttValPair& lhs, const AttValPair& rhs);

bool rank(const EmailCount& lhs, const EmailCount& rhs);

void clearScreen();

#endif /* utility_h */
