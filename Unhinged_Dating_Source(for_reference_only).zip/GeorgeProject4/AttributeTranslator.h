//
//  MemberDatabase.h
//  AttributeTranslator
//
//  Created by Qitong Luan on 3/5/22.
//

#ifndef AttributeTranslator_h
#define AttributeTranslator_h
#include "RadixTree.h"
#include "provided.h"
#include <string>
#include <vector>

class AttributeTranslator {
public:
    AttributeTranslator();
    bool Load(std::string filename);
    std::vector<AttValPair> FindCompatibleAttValPairs(const AttValPair& source) const;
    ~AttributeTranslator();
private:
    RadixTree<std::vector<AttValPair> > reference;
    /* I mapped each key to a vector of compatible pairs*/
};


#endif /* AttributeTranslator_h */
