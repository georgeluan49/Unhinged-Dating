//
//  MatchMaker.cpp
//  GeorgeProject4
//
//  Created by Qitong Luan on 3/6/22.
//

#include "MatchMaker.h"
#include "MemberDatabase.h"
#include "PersonProfile.h"
#include "AttributeTranslator.h"
#include "provided.h"
#include "utility.h"
#include <unordered_map>
#include <set>
#include <vector>
#include <algorithm>
#include <iostream>

MatchMaker::MatchMaker(const MemberDatabase& mdb, const AttributeTranslator& at)
:m_MemberDatabase(&mdb), m_AttributeTranslator(&at)
{}

MatchMaker::~MatchMaker(){}

// If the threshold is 0, the members with 0 matches will not show up in the result.
std::vector<EmailCount> MatchMaker::IdentifyRankedMatches(std::string email,
                                                          int threshold) const {
    std::vector<EmailCount> result;
    
    // Attempt to find the member
    const PersonProfile* client =  m_MemberDatabase->GetMemberByEmail(email);
    
    if (client == nullptr)
        return result;
    std::unordered_map<std::string, int> MatchFinder;
    std::vector<AttValPair> getAttValPairs;
    std::set<AttValPair> uniqueAttValPairs;
    AttValPair avp;
    // Gather the AttValPairs
    for (int i = 0; i < client->GetNumAttValPairs(); i++) {
        client->GetAttVal(i, avp);
        getAttValPairs.push_back(avp);
    }
    for (int i = 0; i < getAttValPairs.size(); i++) {
        std::vector<AttValPair> insert = m_AttributeTranslator->FindCompatibleAttValPairs(getAttValPairs[i]);
        // Construct the unique AttValPair set from each result vector
        std::copy(insert.begin(), insert.end(), std::inserter(uniqueAttValPairs, uniqueAttValPairs.end()));
    }
    for (std::set<AttValPair>::iterator it = uniqueAttValPairs.begin(); it != uniqueAttValPairs.end(); it++) {
        //std::cerr << it->attribute << std::endl;
        std::vector<std::string> matched = m_MemberDatabase->FindMatchingMembers(*it);
        // Count Matching pairs for each member
        for (std::vector<std::string>::iterator it1 = matched.begin(); it1 != matched.end(); it1++) {
            MatchFinder[*it1] ++;
        }
    }
    for (std::unordered_map<std::string, int>::iterator it = MatchFinder.begin(); it != MatchFinder.end(); it++) {
        if (it->second >= threshold && it->first != email) {
            result.push_back(EmailCount(it->first, it->second));
        }
    }
    std::sort(result.begin(), result.end(), &rank); // Sort the result
    return result;
}
