//
//  MemberDatabase.cpp
//  AttributeTranslator
//
//  Created by Qitong Luan on 3/5/22.
//

#include "AttributeTranslator.h"
#include <fstream>

AttributeTranslator::AttributeTranslator(){}

bool AttributeTranslator::Load(std::string filename) {
    std::ifstream dataFile(filename);
    if (!dataFile)
        return false;
    std::string line;
    while (std::getline(dataFile, line)) {
        if (line != "") { // ignores empty lines
            std::string SourceAttVal;
            AttValPair insert;
            int i = line.size()-1;
            while (line.at(i-1) != ',') i--; // Stops right before the ','
            insert.value = line.substr(i, line.size()-i); // get the value
            line = line.substr(0, i-1); // remove the value part
            i -= 2; // move the cursor to the last character of the resulting string
            while (line.at(i-1) != ',') i--;
            insert.attribute = line.substr(i, line.size()-i); // capture the attribute
            SourceAttVal = line.substr(0, i-1); // This will be the key
            std::vector<AttValPair>* result = reference.search(SourceAttVal);
            if (result != nullptr) // if the key already exists, just insert
                result->push_back(insert);
            else { // create a new vector and insert
                std::vector<AttValPair> newVal;
                newVal.push_back(insert);
                reference.insert(SourceAttVal, newVal);
            }
        }
    }
    return true;
}
std::vector<AttValPair> AttributeTranslator::FindCompatibleAttValPairs(const AttValPair& source) const {
    std::vector<AttValPair> result;
    std::string key = source.attribute + "," + source.value;
    std::vector<AttValPair>* searchResult = reference.search(key);
    if (searchResult != nullptr)
    /* if the compatible pairs are found, update the return vector*/
        result = *searchResult;
    return result;
}
AttributeTranslator::~AttributeTranslator(){}
